@extends('web.layouts.main')
@section('content')
        <!-- START: Inner Banner-->
        {{--@include('web.layouts.inner_banner')--}}
        <!-- END: Inner Banner-->
<main class="aboutPg">
   <div class="saleSec">
      <div class="container-fluid">
         <div class="row">
            <div class='alert alert-success' style='margin:10% 0;text-align: center;'>
                    <strong>Thank You. Your payment has been successfully received, we will contact you soon.</strong>
          </div>
         </div>
      </div>
   </div>
</main>
@endsection
@section('css')
<style type="text/css">
</style>
@endsection
@section('js')
@endsection
