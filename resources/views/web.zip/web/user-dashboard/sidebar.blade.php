<div class="menu-container dashboard1">
    <h6>MY ACCOUNT</h6>
    <hr>
    <ul>
        <li><a href="{{route('user_dashboard')}}" class="active">Dashboard</a></li>
        <li><a href="{{route('user_form')}}">Personalized Your Product </a></li>
        <li><a href="{{route('incoming_request')}}">Incoming Request </a></li>
        <li><a href="{{route('user_store')}}">Post Request </a></li>
        <!-- <li><a href="{{route('user_order')}}">Order History</a></li> -->
        <li><a href="{{route('user_account')}}">Account Setting </a></li>
        <li><a href="#">Privacy Setting </a></li>
        <li><a href="{{route('signout')}}">Logout</a></li>
    </ul>
</div>