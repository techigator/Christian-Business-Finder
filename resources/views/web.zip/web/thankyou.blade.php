@extends('web.layouts.main')
@section('content')
<main>
        <!-- START: Inner Banner-->
        {{--@include('web.layouts.inner_banner')--}}
        <!-- END: Inner Banner-->

    



    <section class="about_section_1">
        <div class="container">
            <div class="row">
                    <div class="col-md-12">
<main class="aboutPg">
   <div class="saleSec">
      <div class="container-fluid">
         <div class="row">
<div class="col-md-12">
            <div class='alert alert-success' style='margin: 25% 0 15% 0;text-align: center;'>
                    <strong>Thank you for contacting us, we will get back to you as soon as possible.</strong>
          </div>
          </div>
         </div>
      </div>
   </div>
</main>
</div>



            
              
            </div>

        </div>
    </section>
   








</main>
@endsection
@section('css')
<style type="text/css">
</style>
@endsection
@section('js')
@endsection
